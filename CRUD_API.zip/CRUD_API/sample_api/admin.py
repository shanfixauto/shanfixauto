from django.contrib import admin  
from .models import Engineers  
   
admin.site.register(Engineers)  