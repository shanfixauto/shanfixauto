from .views import EngineerView  
from django.urls import path  
  
urlpatterns = [
      
    path('engineer/', EngineerView.as_view()),  
    path('engineer/<int:id>/', EngineerView.as_view()),  
    path('engineer/<int:id>/update/', EngineerView.as_view())  
]