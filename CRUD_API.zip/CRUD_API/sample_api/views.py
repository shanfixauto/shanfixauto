from django.shortcuts import render

from django.shortcuts import render  
from rest_framework.views import APIView  
from rest_framework.response import Response  
from rest_framework import status  
from .models import Engineers  
from .serializers import EngineersSerializer  
from django.shortcuts import get_object_or_404  

  
class EngineerView(APIView):  
  
    def get(self, request, id):  
        result = Engineers.objects.get(id=id)  
        if id:  
            serializers = EngineersSerializer(result)  
            return Response({'success': 'success', "engineers":serializers.data}, status=200)  
  
        result = Engineers.objects.all()  
        serializers = EngineersSerializer(result, many=True)  
        return Response({'status': 'success', "engineers":serializers.data}, status=200)  
  
    def post(self, request):  
        serializer = EngineersSerializer(data=request.data)  
        if serializer.is_valid():  
            serializer.save()  
            return Response({"status": "success", "data": serializer.data}, status=status.HTTP_200_OK)  
        else:  
            return Response({"status": "error", "data": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)  
  
    def patch(self, request, id):  
        result = Engineers.objects.get(id=id)  
        serializer = EngineersSerializer(result, data = request.data, partial=True)  
        if serializer.is_valid():  
            serializer.save()  
            return Response({"status": "success", "data": serializer.data})  
        else:  
            return Response({"status": "error", "data": serializer.errors})  
  
    def delete(self, request, id=None):  
        result = get_object_or_404(Engineers, id=id)  
        result.delete()  
        return Response({"status": "success", "data": "Record Deleted"})  
