from rest_framework import serializers  
from .models import Engineers  
  
class EngineersSerializer(serializers.ModelSerializer):  
    first_name = serializers.CharField(max_length=200, required=True)  
    last_name = serializers.CharField(max_length=200, required=True)  
    department = serializers.CharField(max_length=200, required=True)  
    service_number = serializers.IntegerField()  
    mobile = serializers.CharField(max_length=10, required=True)

    class Meta:  
        model = Engineers  
        fields = ('__all__')    
  
    def create(self, validated_data):  
      
        # Create and return a new Engineer instance, given the validated data. 
       
        return Engineers.objects.create(**validated_data)  
  
    def update(self, instance, validated_data):  
       
        # Update and return an existing Engineer instance, given the validated data. 
          
        instance.first_name = validated_data.get('first_name', instance.first_name)  
        instance.last_name = validated_data.get('last_name', instance.last_name)  
        instance.department = validated_data.get('department', instance.department)  
        instance.service_number = validated_data.get('service_number', instance.service_number)  
        instance.mobile = validated_data.get('mobile', instance.mobile)  
  
        instance.save()  
        return instance  